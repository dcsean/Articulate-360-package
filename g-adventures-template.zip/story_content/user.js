// User defined code goes here. This code is valid for Articulate 360
// this script will allow you to add a company logo, email button, enlarge screen
// and a toggle for subtitles, course progress and subtitle button
// completion percentage, email and subtitles

// init function
// creates objects that will hold DOM elements
// sets email element  
// adds all buttons to the control panel
// waits for elements to be visible in screen and initializes init function 
// create listeners for subtitles and enlarge screen button

// checkCurrentStatus
// checks on toggle boolean and hides/show subtitles

// retrieveSubtitles
// filters groups by height. subtitles should be 74px height

// subtitlesSwitch
// toggles the subtitles boolean and changes the subtitles visibility

// enlarge screen
// enlarges content from selfpace module

var	toggle = true,
	controlNode = null,
	subtitlesButtonNode = document.createElement("div"),
	progressBarObject = document.createElement("div"),
	emailButtonNode = document.createElement("a"),
	slideNumberNode = document.createElement("div"),
	enlargeButtonNode = document.createElement("div"),
	menuButtonNode = null,
	
	arrFromList,
	menuCollectionNodes,
	emailsubject = 'Feedback - module 3',
	emailbody = 'What was the slide number of the issue?%0AWhat was the issue?',
	mailto = 'onlinelearning@gadventures.com',
	initInterval = setInterval(init, 1000),
	checkCurrentStatusInterval;

// initializes variables when user.js is called for first time
function init(){
	//giving IDs to email elements
	emailButtonNode.id = 'emailIcon';
	subtitlesButtonNode.id = 'subtitlesIcon';
	slideNumberNode.id = 'slideNumber';
	enlargeButtonNode.id = 'enlargeIcon';
	progressBarObject.id = 'courseProgressBar';
	// get all elements from menu
	menuCollectionNodes = document.getElementsByClassName('cs-listitem');
	//adding properties to the A tag
	emailButtonNode.href = 'mailto:'+mailto+'?subject='+emailsubject+'&body='+emailbody;
	//if this element on the player exist initialize controlNode variable
	if (document.getElementsByClassName("controls-group control-bar cs-seekcontrol progress-control")[0]){
		controlNode = document.getElementsByClassName("controls-group control-bar cs-seekcontrol progress-control")[0].childNodes[0];
	} 
	//if controlNode has been filled append these elements to the DOM
	if(controlNode){
		controlNode.appendChild(subtitlesButtonNode);
		controlNode.appendChild(emailButtonNode);
		controlNode.appendChild(slideNumberNode);
		controlNode.appendChild(enlargeButtonNode);
		controlNode.appendChild(progressBarObject);
	}
	//clear init interval
	if(controlNode) clearInterval(initInterval);
	//sets check current status interval
	checkCurrentStatusInterval = setInterval(checkCurrentStatus, 10);
	// add subtitles button a listener
	enlargeButtonNode.addEventListener('click', enlargeScreen);
	subtitlesButtonNode.addEventListener('click', subTitlesSwitch);
	//menuButtonNode.className += "cs-button";
	menuButtonNode = document.getElementById("tab-outline");
	menuButtonNode.classList.add('btn');
	menuButtonNode.classList.add('cs-button');
	// progress will when the mouse moves
	document.addEventListener("mousemove", pointerMoves);

	findActiveSlide();
	for(var el in menuCollectionNodes){
		elTemp = menuCollectionNodes[el];
		elTemp.conClick = function(e){console.log(e);}
	}

}

// callback from an event listener to check on the toggle variable
// fills the subTitle object with the subtitles DOM element
function checkCurrentStatus(){
	if(toggle !== null){
		arrFromList = Array.prototype.slice.call(document.getElementsByClassName("slide-object slide-object-objgroup shown"));
		subTitlesObjectNode = retrieveSubtitles(arrFromList);
	}
	if (!toggle) {
		if (subTitlesObjectNode.style !== undefined) subTitlesObjectNode.style.display = 'block'
	}else{
		if (subTitlesObjectNode.style !== undefined) subTitlesObjectNode.style.display = 'none';
	}
}

// this element gets the subtitle element in the DOM
// makes toggle go false to hide subtitles element in the DOm
function retrieveSubtitles(collection){
	if(collection.length !== 0){
		for(var elem in collection){
			if(collection[elem].style.height === '74'+'px' || collection[elem].style.height === '75'+'px'){
				return collection[elem];
			}
		}
	}
	return false;
toggle = false;
};

// subtitle listener callback function, which works as a toggle.
function subTitlesSwitch(e){
	toggle = !toggle;
	if (subTitlesObjectNode.style !== undefined) {
		toggle ? subTitlesObjectNode.style.display = 'block' : subTitlesObjectNode.style.display = 'none';
	}
}

// callback from the enlarge button listener
// this function enlarges screen
function enlargeScreen(){
	//var elem = document.body;
	var elem = document.getElementById("presentation-container");	
	if (elem.requestFullscreen) {
	  elem.requestFullscreen();
	} else if (elem.msRequestFullscreen) {
	  elem.msRequestFullscreen();
	} else if (elem.mozRequestFullScreen) {
	  elem.mozRequestFullScreen();
	} else if (elem.webkitRequestFullscreen) {
	  elem.webkitRequestFullscreen();
	}
}

function pointerMoves(e){
	findActiveSlide();
	updateProgress();
}

function updateProgress(){
	completePercentage = findActiveSlide() / Number(menuCollectionNodes.length - 1);
	userProgress(completePercentage);
}

function userProgress(progressPercentage){
	//console.log(progressPercentage);

	if(progressPercentage < 0.2){
		progressBarObject.style.backgroundPosition = "0px 0px";
	}else if(progressPercentage < 0.4){
		progressBarObject.style.backgroundPosition = "-45px 0px";
	}
	else if(progressPercentage < 0.6){
		progressBarObject.style.backgroundPosition = "-90px 0px";
	}
	else if(progressPercentage < 0.8){
		progressBarObject.style.backgroundPosition = "-135px 0px";
		
	}else if(progressPercentage < 1){
		progressBarObject.style.backgroundPosition = "-180px 0px";
	}else{
		progressBarObject.style.backgroundPosition = "-225px 0px";
	}
}

var tempSlide = 1;
var prevSlide = -1;
function findActiveSlide(){

	for (var i = 1; i < menuCollectionNodes.length; i++) {
	    if( menuCollectionNodes[i].classList.contains('cs-selected')){
	    	tempSlide = i;
	    } 
	}
	if(prevSlide !== undefined && prevSlide > 0){
		if(prevSlide !== tempSlide){
			globalPreviousSlide = prevSlide;
			globalCurrentSlide = tempSlide;
		}
	}
	prevSlide = tempSlide;
	return tempSlide;
}
